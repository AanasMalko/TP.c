#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

typedef struct voiture
{
    char marque[50];    // exemple(audi,dacia,....)
    char modele[50];    // exemple(RS6,duster... )
    int annee;          // exemple(2025,1999,...)
    char version[50];   // exemple(gt line,sline... )
    char carburant[20]; // exemple(essence/gazoil/hybride/electrique)
    float prix;         // exemple(800000.00,120000.00,....)
    struct voiture *prev;
    struct voiture *next;
} voiture;

voiture *ajouter_voiture() // la fonction principale d'ajout
{
    voiture *nouvelle = (voiture *)malloc(sizeof(voiture)); // allocation dynamic
    if (!nouvelle)                                          // verification d'allocation
    {
        printf("Erreur d'allocation de memoire\n");
        return NULL;
    }

    printf("Marque    : "); // la saisie du marque
    fflush(stdout);
    fgets(nouvelle->marque, 50, stdin);
    strtok(nouvelle->marque, "\n");

    printf("Modele    : "); // la saisie du modele
    fflush(stdout);
    fgets(nouvelle->modele, 50, stdin);
    strtok(nouvelle->modele, "\n");

    printf("Annee     : "); // la saisie d'annee
    fflush(stdout);
    scanf("%d", &nouvelle->annee);
    getchar();

    printf("Version   : "); // la saisie de la Version
    fflush(stdout);
    fgets(nouvelle->version, 50, stdin);
    strtok(nouvelle->version, "\n");

    printf("Carburant : "); // la saisie de la version
    fflush(stdout);
    fgets(nouvelle->carburant, 50, stdin);
    strtok(nouvelle->carburant, "\n");

    printf("Prix      : "); // la saisie du prix
    fflush(stdout);
    scanf("%f", &nouvelle->prix);

    nouvelle->next = NULL;
    nouvelle->prev = NULL;

    return nouvelle;
}

voiture *ajouter_voiture_DEBUT(voiture *head) // l'ajout au debut
{
    voiture *NV = ajouter_voiture(); // l'appel de la fonction d'ajout

    if (head == NULL) // verfication si la list est vide
    {
        head = NV;
    }
    else // si la est list plein
    {
        NV->next = head;
        head = NV;
    }
    return head;
}

voiture *ajouter_voiture_FIN(voiture *head) // l'ajout a la fin
{
    voiture *NV = ajouter_voiture(); // l'appel de la fonction d'ajout

    if (head == NULL) // verfication si la list est vide
    {
        head = NV;
    }
    else
    {
        voiture *ptr = head;
        while (ptr->next != NULL)
        {
            ptr = ptr->next;
        }
        ptr->next = NV;
        NV->prev = ptr;
    }
    return head;
}

voiture *ajouter_voiture_specifique(voiture *head) // l'ajout d'une voiture apres une voiture specifique
{
    voiture *NV = ajouter_voiture(); // creation du nouveaux element
    printf("Saisir les information de la voiture specifique dans le stock : ");
    voiture *voiture_specifique = ajouter_voiture(); // saisie et stockage d'information dans un element
    voiture *ptr = head;

    while (ptr != voiture_specifique && ptr->next != NULL)
    {
        ptr = ptr->next;
    }
    if (ptr == voiture_specifique)
    {
        NV->prev = ptr;
        NV->next = ptr->next;
        ptr->next = NV;
    }
    else
    {
        printf("la voiture specifique n'est pas disponible \n");
    }
    free(voiture_specifique);
    return head;
}

voiture *suppression_voiture_debut(voiture *head)
{
    if (head == NULL) // condition si la list est vide
    {
        printf("le stock est vide !!");
    }
    else
    {
        voiture *ptr = head;
        ptr->next->prev = NULL;
        head = ptr->next;
        free(ptr);
    }
    return head;
}

voiture *suppression_voiture_fin(voiture *head)
{
    if (head == NULL) // condition si la list est vide
    {
        printf("le stock est vide !!");
    }
    else if (head->next == NULL) // condition si il'a un seul element dans la list
    {
        free(head);
        head = NULL;
    }
    else
    {
        voiture *ptr = head;
        while (ptr->next != NULL)
        {
            ptr = ptr->next;
        }
        ptr->prev->next = NULL;
        free(ptr);
    }
    return head;
}

voiture *suppression_voiture_specifique(voiture *head)
{
    if (head == NULL) // condition si la liste est vide
    {
        printf("le stock est vide !!\n");
    }
    else
    {
        printf("Entrez les informations de la voiture specifique que vous souhaitez supprimer : \n");
        voiture *voiture_specifique = ajouter_voiture();
        voiture *ptr = head;

        while (ptr != NULL && ptr != voiture_specifique)
        {
            ptr = ptr->next;
        }

        if (ptr == voiture_specifique) // trouve
        {
            if (ptr == head) // Suppression au debut
            {

                head = head->next;
                if (head != NULL)
                    head->prev = NULL;
                free(ptr);
            }
            else if (ptr->next == NULL) // Suppression a la fin
            {
                ptr->prev->next = NULL;
                free(ptr);
            }
            else // Suppression au milieu
            {
                ptr->prev->next = ptr->next;
                ptr->next->prev = ptr->prev;
                free(ptr);
            }
        }
        else
        {
            printf("La voiture specifique n'est pas disponible\n");
        }

        free(voiture_specifique);
    }
    return head;
}

voiture *modifier_voiture_specifique(voiture *head)
{
    if (head == NULL)
    {
        printf("Le stock est vide !!\n");
        return head;
    }

    char marque[50], modele[50], version[50], carburant[50];
    int annee;
    float prix;

    printf("Entrez les informations de la voiture a modifier :\n");

    printf("Marque    : ");
    fgets(marque, 50, stdin);
    strtok(marque, "\n");

    printf("Modele    : ");
    fgets(modele, 50, stdin);
    strtok(modele, "\n");

    printf("Annee     : ");
    scanf("%d", &annee);
    getchar();

    printf("Version   : ");
    fgets(version, 50, stdin);
    strtok(version, "\n");

    printf("Carburant : ");
    fgets(carburant, 50, stdin);
    strtok(carburant, "\n");

    printf("Prix      : ");
    scanf("%f", &prix);
    getchar();

    voiture *ptr = head;
    while (ptr != NULL)
    {
        if ((strcmp(ptr->marque, marque) == 0) &&
            (strcmp(ptr->modele, modele) == 0) &&
            (ptr->annee == annee) &&
            (strcmp(ptr->version, version) == 0) &&
            (strcmp(ptr->carburant, carburant) == 0) &&
            (ptr->prix == prix))
        {
            printf("\n--- Donnez les nouvelles informations : ---\n");
            voiture *new_infos = ajouter_voiture();

            strcpy(ptr->marque, new_infos->marque);
            strcpy(ptr->modele, new_infos->modele);
            ptr->annee = new_infos->annee;
            strcpy(ptr->version, new_infos->version);
            strcpy(ptr->carburant, new_infos->carburant);
            ptr->prix = new_infos->prix;

            free(new_infos);
            return head;
        }

        ptr = ptr->next;
    }

    printf("La voiture n'a pas ete trouvée\n");
    return head;
}

void rechercher_voiture(voiture *head)
{
    int choix_recherche;

    do
    {
        printf("\n1. Recherche par marque\n2. Recherche par modele\n3. Recherche par annee\n4. Recherche par prix\n5. Recherche avancée (tous les criteres)\n6. Retour\n");
        printf("Choix : ");
        scanf("%d", &choix_recherche);
        getchar();

        voiture *ptr;

        switch (choix_recherche)
        {
        case 1:
        {
            char marque_recherche[50];
            printf("Entrez la marque a rechercher: ");
            fgets(marque_recherche, 50, stdin);
            strtok(marque_recherche, "\n");

            ptr = head;
            while (ptr != NULL)
            {
                if (strcmp(ptr->marque, marque_recherche) == 0)
                {
                    printf("\nMarque: %s\nModele: %s\nAnnee: %d\nVersion: %s\nCarburant: %s\nPrix: %.2f\n",
                           ptr->marque, ptr->modele, ptr->annee, ptr->version, ptr->carburant, ptr->prix);
                }
                ptr = ptr->next;
            }
            break;
        }

        case 2:
        {
            char modele_recherche[50];
            printf("Entrez le modele a rechercher: ");
            fgets(modele_recherche, 50, stdin);
            strtok(modele_recherche, "\n");

            ptr = head;
            while (ptr != NULL)
            {
                if (strcmp(ptr->modele, modele_recherche) == 0)
                {
                    printf("\nMarque: %s\nModele: %s\nAnnee: %d\nVersion: %s\nCarburant: %s\nPrix: %.2f\n",
                           ptr->marque, ptr->modele, ptr->annee, ptr->version, ptr->carburant, ptr->prix);
                }
                ptr = ptr->next;
            }
            break;
        }

        case 3:
        {
            int annee_recherche;
            printf("Entrez l'annee a rechercher: ");
            scanf("%d", &annee_recherche);

            ptr = head;
            while (ptr != NULL)
            {
                if (ptr->annee == annee_recherche)
                {
                    printf("\nMarque: %s\nModele: %s\nAnnee: %d\nVersion: %s\nCarburant: %s\nPrix: %.2f\n",
                           ptr->marque, ptr->modele, ptr->annee, ptr->version, ptr->carburant, ptr->prix);
                }
                ptr = ptr->next;
            }
            break;
        }

        case 4:
        {
            float prix_recherche;
            printf("Entrez le prix a rechercher: ");
            scanf("%f", &prix_recherche);

            ptr = head;
            while (ptr != NULL)
            {
                if (ptr->prix == prix_recherche)
                {
                    printf("\nMarque: %s\nModele: %s\nAnnee: %d\nVersion: %s\nCarburant: %s\nPrix: %.2f\n",
                           ptr->marque, ptr->modele, ptr->annee, ptr->version, ptr->carburant, ptr->prix);
                }
                ptr = ptr->next;
            }
            break;
        }

        case 5:
        {
            char marque[50], modele[50], version[50], carburant[50];
            int annee;
            float prix;

            printf("Entrez la marque: ");
            fgets(marque, 50, stdin);
            strtok(marque, "\n");
            printf("Entrez le modele: ");
            fgets(modele, 50, stdin);
            strtok(modele, "\n");
            printf("Entrez l'annee: ");
            scanf("%d", &annee);
            getchar();
            printf("Entrez la version: ");
            fgets(version, 50, stdin);
            strtok(version, "\n");
            printf("Entrez le carburant: ");
            fgets(carburant, 50, stdin);
            strtok(carburant, "\n");
            printf("Entrez le prix: ");
            scanf("%f", &prix);

            ptr = head;
            while (ptr != NULL)
            {
                if ((strcmp(ptr->marque, marque) == 0) &&
                    (strcmp(ptr->modele, modele) == 0) &&
                    (ptr->annee == annee) &&
                    (strcmp(ptr->version, version) == 0) &&
                    (strcmp(ptr->carburant, carburant) == 0) &&
                    (ptr->prix == prix))
                {
                    printf("\nMarque: %s\nModele: %s\nAnnee: %d\nVersion: %s\nCarburant: %s\nPrix: %.2f\n",
                           ptr->marque, ptr->modele, ptr->annee, ptr->version, ptr->carburant, ptr->prix);
                }
                ptr = ptr->next;
            }
            break;
        }

        case 6:
            break;

        default:
            printf("Choix invalide.\n");
        }
    } while (choix_recherche != 6);
}

// Fonction pour sauvegarder les données dans un fichier local
void sauvegarder_voitures(voiture *head)
{
    FILE *f = fopen("stock.txt", "w");
    if (!f)
    {
        printf("Erreur lors de l'ouverture du fichier pour l'ecriture\n");
        return;
    }
    voiture *ptr = head;
    while (ptr != NULL)
    {
        fprintf(f, "%s,%s,%d,%s,%s,%.2f\n",
                ptr->marque, ptr->modele, ptr->annee,
                ptr->version, ptr->carburant, ptr->prix);
        ptr = ptr->next;
    }
    fclose(f);
}

// Fonction pour charger les données depuis un fichier local
voiture *charger_voitures()
{
    FILE *f = fopen("stock.txt", "r");
    if (!f)
    {
        printf("Aucune sauvegarde trouvee, demarrage avec une liste vide.\n");
        return NULL;
    }

    voiture *head = NULL, *last = NULL;
    voiture *nv;
    while (!feof(f))
    {
        nv = (voiture *)malloc(sizeof(voiture));
        if (fscanf(f, "%49[^,],%49[^,],%d,%49[^,],%49[^,],%f\n",
                   nv->marque, nv->modele, &nv->annee,
                   nv->version, nv->carburant, &nv->prix) == 6)
        {
            nv->next = NULL;
            nv->prev = last;
            if (last)
                last->next = nv;
            else
                head = nv;
            last = nv;
        }
        else
        {
            free(nv);
        }
    }

    fclose(f);
    return head;
}

// Fonction principale avec menu
int main()
{
    voiture *stock = charger_voitures();
    int choix_main, choix_gestion, choix_ajout, choix_suppression;

    do
    {
        printf("\n1=>Gestion d'un Concessionnaire de Voitures\n2=>Quitter\n\nMenu Principale\nChoix : ");
        scanf("%d", &choix_main);
        getchar(); // pour consommer '\n'

        switch (choix_main)
        {
        case 1:
            do
            {
                printf("\nGestion d'un Concessionnaire de Voitures\n");
                printf("1=> Ajout d'une voiture au stock\n");
                printf("2=> Modification d'une voiture au stock\n");
                printf("3=> Suppression d'une voiture au stock\n");
                printf("4=> Recherche d'une voiture au stock\n");
                printf("5=> Affichage les voitures disponibles dans le stock\n");
                printf("6=> MENU principal\n\nChoix : ");
                scanf("%d", &choix_gestion);
                getchar(); // pour consommer '\n'

                switch (choix_gestion)
                {
                case 1:
                    printf("\n1. Ajout au debut\n2. Ajout a la fin\n3. Ajout apres une voiture specifique\n4. Retour\nChoix : ");
                    scanf("%d", &choix_ajout);
                    getchar();
                    if (choix_ajout == 1)
                        stock = ajouter_voiture_DEBUT(stock);
                    else if (choix_ajout == 2)
                        stock = ajouter_voiture_FIN(stock);
                    else if (choix_ajout == 3)
                        stock = ajouter_voiture_specifique(stock);
                    break;
                case 2:
                    stock = modifier_voiture_specifique(stock);
                    break;
                case 3:
                    printf("\n1. Suppression au debut\n2. Suppression a la fin\n3. Suppression apres une voiture spécifique\n4. Retour\nChoix : ");
                    scanf("%d", &choix_suppression);
                    getchar();
                    if (choix_suppression == 1)
                        stock = suppression_voiture_debut(stock);
                    else if (choix_suppression == 2)
                        stock = suppression_voiture_fin(stock);
                    else if (choix_suppression == 3)
                        stock = suppression_voiture_specifique(stock);
                    break;
                case 4:
                    rechercher_voiture(stock);
                    break;
                case 5:
                {
                    voiture *ptr = stock;
                    while (ptr != NULL)
                    {
                        printf("\nMarque: %s\nModele: %s\nAnnee: %d\nVersion: %s\nCarburant: %s\nPrix: %.2f\n",
                               ptr->marque, ptr->modele, ptr->annee, ptr->version, ptr->carburant, ptr->prix);
                        ptr = ptr->next;
                    }
                }
                break;
                }
            } while (choix_gestion != 6);
            break;

        case 2:
            sauvegarder_voitures(stock);
            printf("Donnees sauvegardees. Fermeture du programme.\n");
            break;

        default:
            printf("Choix invalide.\n");
        }

    } while (choix_main != 2);

    return 0;
}